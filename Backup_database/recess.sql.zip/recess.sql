-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2019 at 12:05 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recess`
--

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `ApplicantID` varchar(25) NOT NULL,
  `LoanAmount` int(50) NOT NULL,
  `LoanAmountTerm` int(50) NOT NULL,
  `Loan_status` text NOT NULL,
  `date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan_applicant`
--

CREATE TABLE `loan_applicant` (
  `date` varchar(50) NOT NULL,
  `ApplicantID` varchar(20) NOT NULL,
  `ApplicantIncome` int(30) NOT NULL,
  `CoapplicantIncome` int(30) NOT NULL,
  `CreditHistory` int(30) NOT NULL,
  `Education` text NOT NULL,
  `Gender` text NOT NULL,
  `LoanAmount` int(30) NOT NULL,
  `LoanAmountTerm` int(30) NOT NULL,
  `Marital_status` text NOT NULL,
  `Number_of_dependents` int(15) NOT NULL,
  `PropertyArea` text NOT NULL,
  `Self_employed` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `Client_ID` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `user_type`, `Client_ID`) VALUES
('iamoko', '4826', 'admin', ''),
('client', '1234', 'client', 'LP002019'),
('admin', 'admin', 'admin', ''),
('client2', '12345', 'client', 'LP002017');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
